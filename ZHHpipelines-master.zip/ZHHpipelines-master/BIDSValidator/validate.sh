docker run -it --rm -v /analysis/BIDS/:/data:ro bids/validator /data
